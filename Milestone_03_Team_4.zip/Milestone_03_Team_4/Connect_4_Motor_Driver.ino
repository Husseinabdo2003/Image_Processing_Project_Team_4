#include <AccelStepper.h>
#include <Servo.h>
// L298N inputs
#define IN1_PIN 8
#define IN2_PIN 9
#define IN3_PIN 10
#define IN4_PIN 11
// Servo pin
#define SERVO_PIN 6
// Use FULL4WIRE mode: pins = IN1, IN3, IN2, IN4
AccelStepper stepper(AccelStepper::FULL4WIRE,
                     IN1_PIN, IN3_PIN,
                     IN2_PIN, IN4_PIN);
Servo dropper;
const long STEPS_PER_COL = 1600;  // adjust for your belt/pulley pitch
void setup() {
  Serial.begin(9600);
  // Stepper params
  stepper.setMaxSpeed(1000);
  stepper.setAcceleration(500);
  // Servo setup
  dropper.attach(SERVO_PIN);
  dropper.write(0);  // closed
}
void drop_chip() {
  dropper.write(90);  // open
  delay(300);
  dropper.write(0);   // close
  delay(300);
}
void move_to_column(int col) {
  long target = col * STEPS_PER_COL;
  stepper.moveTo(target);
  while (stepper.distanceToGo() != 0) {
    stepper.run();
  }
  drop_chip();
}
void loop() {
  if (Serial.available()) {
    int col = Serial.parseInt();
    if (col >= 0 && col <= 6) {
      move_to_column(col);
    }
  }
}